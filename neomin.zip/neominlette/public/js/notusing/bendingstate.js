(function(global){
	global.BendingState = {
	  NOBEND : 0,
	  RIGHTBEND : 1, //= 1
	  LEFTBEND : -1,  //=-1
	  RIGHTEXIST : 2,//= 2
	  LEFTEXIST : -2  //=-2		
	}
}(window))
